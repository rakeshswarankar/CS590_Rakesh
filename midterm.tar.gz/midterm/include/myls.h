/* This is the header file for myls command. It use by supportive file myls.c and main.c file.
*  Author : Rakesh Kumar Swarankar
*  Date   : 06/24/2015
*  Work   : CS590 Midterm Project
*  FileNm : myls.h
*/

#include<stdio.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<dirent.h>
#include<unistd.h>
#include<string.h>
#include<pwd.h>
#include<stdlib.h>
#include<grp.h>
#include<sys/time.h>
#include<time.h>

struct OptionFlag
{
    unsigned int optionH:1; // For Help 
    unsigned int optionS:1; // list file size in blocks
    unsigned int optionL:1; // ;png listing
    unsigned int optionR:1; // subdirectory Recursive 
    unsigned int optionT:1; // Sort by modification time
    unsigned int optionU:1; // Sort by status modification time
    unsigned int optionC:1; // Sort by access time
    unsigned int optionSort:1; // Sort by File Size in DESC order
};

static struct OptionFlag optionFlag;
struct FileList
{
    char fileName[128];
    unsigned int size;
    time_t time;
}fileList[256];

char *populateDirectoryName(int *index, char **argv);
void optionHelp();
void getFilePermission(struct stat fileStat,char permission[]);
char getFileType(struct stat fileStat);
void optionLong(char *dirName,int dirFlag);
void optionDefault(char *dirName, int dirFlag);
void optionTime(char *dirName);
void optionRecursive(char *dirName);
void optionSort(char *dirName);
void optionSize(char *dirName);
void listContent(char* dirName);
int populateFlag(int argc, char **argv);

